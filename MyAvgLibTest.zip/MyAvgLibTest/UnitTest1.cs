﻿using Xunit;
using MyAvgLib;

namespace MyAvgLibTest;

public class UnitTest1
{
    [Fact]
    public void Avg_TwoNumbers()
    {
        double result = Average.Avg(2, 6);
        Assert.Equal(4.0, result, 5);
    }

    [Fact]
    public void Avg_ThreeNumbers()
    {
        double result = Average.Avg(2, 6, 7);
        Assert.Equal(5.0, result, 5);
    }
}
